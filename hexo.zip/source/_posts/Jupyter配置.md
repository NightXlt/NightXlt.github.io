title: Jupyter配置
date: 2019-1-5
tags: [Leetcode,字节跳动]
categories: algorithm
description: 　　
---
　　看了网上很多配置工作路径的，全坑人的呀，每一个配上了，最后还是靠自己丰衣足食。一步步看cmd命令解释生生一次次试错试出来啦。
 ```python
 Jupyter-notebook --generate-config
```
再将生成文件的目录的工作路径改了即可。以及右击Jupyter快捷方式中的属性（起始位置%HOMEPATH%后的东西全删掉）