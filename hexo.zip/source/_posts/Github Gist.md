title: Github Gist入坑
date: 2018-05-12
tags: [Android]
categories: skills
description: github gist简介
---

## github gist简介

### gist是基于版本控制的共享链接。再也不用打开qq收文件啦 ~ _ ~,而且最良心的还是竟然还支持私有，天，git仓库都还要付费的。。。


## gist生成步骤
 
 #### 1. 创建一个git仓库
 #### 2. 在git仓库下的代码或输出日志，待处理任务等上右键Create_Gist
 ![android_gist](/images/1.png)
 
 #### 3. 配置gist属性即可
 
 #### 4. 登录github或输入Token
 ![enter description here](/images/2.png)
 
 ####  5. 共享友链给你的朋友